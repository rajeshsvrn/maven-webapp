#! /bin/bash
echo "Testing started..."
sleep 10
echo "Test completed"

